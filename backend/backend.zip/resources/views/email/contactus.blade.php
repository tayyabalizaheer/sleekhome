<h3>Name</h3>
{{$name??""}}
<br><br>
<h3>Email</h3>
{{$email??""}}
<br><br>
<h3>Message</h3>
{{$detail??""}}
