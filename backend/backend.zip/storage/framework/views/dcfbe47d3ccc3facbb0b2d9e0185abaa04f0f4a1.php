<h3>Name</h3>
<?php echo e($name??""); ?>

<br><br>
<h3>Email</h3>
<?php echo e($email??""); ?>

<br><br>
<h3>Message</h3>
<?php echo e($detail??""); ?>

<?php /**PATH C:\wamp64\www\sleek_home\backend\resources\views/email/contactus.blade.php ENDPATH**/ ?>